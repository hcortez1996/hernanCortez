import folium
import csv
from random import seed
from random import random

#create map using folium import (zoomed in and centered on US)
m = folium.Map(location=[39.828348,-98.579479], zoom_start=5, ) 

#open immigration 12-1-19 (processed).csv file and populate them to the map
with open('data/processedData/immigration 12-1-19 (processed).csv','r',encoding='ISO-8859-1') as rf:
    csvReader = csv.DictReader(rf) #reader to read in each row in csv file
    for row in csvReader: #loop through each row in csv file
        folium.Marker( #marker object for each row and using attribues accordingly
            location = [row['tweetLat'],row['tweetLog']], icon = folium.Icon(color=row['tweetRawSentimentColor']),
            popup=("{0}, {1}".format(row['tweetCity'], row['tweetCreated']) +'\n'+
            "Tweet Text: {0}".format(row['tweetText']))
            ).add_to(m) #add marker to map

#open immigrants 12-2-19 (processed).csv file and populate them to the map
with open('data/processedData/immigrants 12-2-19 (processed).csv','r',encoding='ISO-8859-1') as rf:
    csvReader = csv.DictReader(rf) #reader to read in each row in csv file
    for row in csvReader: #loop through each row in csv file
        folium.Marker( #marker object for each row and using attribues accordingly
            location = [row['tweetLat'],row['tweetLog']], icon = folium.Icon(color=row['tweetRawSentimentColor']),
            popup=("{0}, {1}".format(row['tweetCity'], row['tweetCreated']) +'\n'+
            "Tweet Text: {0}".format(row['tweetText']))
            ).add_to(m) #add marker to map

#open keywords (processed).csv file and populate them to the map
with open('data/processedData/keywords (processed).csv','r',encoding='ISO-8859-1') as rf:
    csvReader = csv.DictReader(rf) #reader to read in each row in csv file 
    for row in csvReader: #loop through each row in csv file
        folium.Marker( #marker object for each row and using attribues accordingly
            location = [row['tweetLat'],row['tweetLog']], icon = folium.Icon(color=row['tweetRawSentimentColor']),
            popup=("{0}, {1}".format(row['tweetCity'], row['tweetCreated']) +'\n'+
            "Tweet Text: {0}".format(row['tweetText']))
            ).add_to(m) #add marker to map

m.save('tweets.html') # creates the map and outputs the html
print(m) # prompt message to show me program is done

