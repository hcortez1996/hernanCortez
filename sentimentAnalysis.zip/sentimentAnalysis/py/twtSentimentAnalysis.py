# -*- coding: utf-8 -*- 
import csv
import re
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer 
from random import seed
from random import random

#fuction that uses vaderSentiment to determine sentiment scores on
#text that is passed in. also added color as an output for the map markers
def sentiment_scores(text): 
    # Create a SentimentIntensityAnalyzer object. 
    sid_obj = SentimentIntensityAnalyzer() 
  
    # polarity_scores method of SentimentIntensityAnalyzer 
    # oject gives a sentiment dictionary. 
    # which contains pos, neg, neu, and compound scores. 
    sentiment_dict = sid_obj.polarity_scores(text) 
      
    # decide sentiment as positive, negative and neutral 
    if sentiment_dict['compound'] >= 0.05 : 
        color = 'green'  
    elif sentiment_dict['compound'] <= - 0.05 : 
        color = 'red' 
    else : 
        color = 'gray'
    return sentiment_dict, color

#function that takes in text and cleans it of special characters and the links 
# at the end of tweets
def clean_tweet(tweet): 
		#Utility function to clean tweet text by removing links, special characters 
		#using simple regex statements. 
		return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", tweet).split())

# seed random number generator
seed()

#read in the tweets from tweets.csv
with open('data/immigrants 12-2-19.csv','r',encoding='ISO-8859-1') as rf:
	#write tweets2.csv and populate it with transferring data from tweets.csv in addition to adding sentiment scores and colors
	with open('data/processedData/immigrants 12-2-19 (processed).csv','w',newline='',encoding='ISO-8859-1') as wf:
		csvReader = csv.DictReader(rf)
		csvWriter = csv.DictWriter(wf, fieldnames= ['tweetID','tweetText','tweetCleanText','tweetCity','tweetBoundingBox',
													'tweetLog','tweetLat','tweetCreated','tweetRawSentimentDict',
													'tweetCleanSentimentDict','tweetRawSentimentColor','tweetCleanSentimentColor'])
		csvWriter.writeheader()
		#copying data from tweets.csv to tweets2.csv, also use sentiment_scores function to process tweet texts
		#and to produce sentiment colors
		for row in csvReader:
			tID,tText,tCity,tBbox,tLog,tLat,tCreated=row['tweetID'],row['tweetText'],row['tweetCity'],row['tweetBoundingBox'],row['tweetLog'],row['tweetLat'],row['tweetCreated']
			tCleanText = clean_tweet(tText)
			tRawSentDict, tRawSentColor, = sentiment_scores(tText)
			tCleanSentDict, tCleanSentColor = sentiment_scores(tCleanText)
			csvWriter.writerow({
				'tweetID':tID,
				'tweetText':tText,
				'tweetCleanText':tCleanText,
				'tweetCity':tCity,
				'tweetBoundingBox':tBbox,
				'tweetLog':float(tLog) + random(),
				'tweetLat':float(tLat) + random(),
				'tweetCreated':tCreated,
				'tweetRawSentimentDict':tRawSentDict,
				'tweetCleanSentimentDict':tCleanSentDict,
				'tweetRawSentimentColor':tRawSentColor,
				'tweetCleanSentimentColor':tCleanSentColor
			})
	wf.close()
rf.close()
