import tweepy
import sys
import jsonpickle
import os
import re
import csv
import folium
import re
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer 
from random import seed
from random import random
import random


# Variables that contains the user credentials to access Twitter API 
ACCESS_TOKEN = '1171778869294243840-b6RZBZlGC3HeJn1iMm8jlxx5OhSUNV'
ACCESS_SECRET = 'rseyleeT98V51pPGIgx31iruMqvwkYxeYRTirGOiW98mH'
CONSUMER_KEY = 'ttbIZuM5NtvsugzkKXhxlQ35x'
CONSUMER_SECRET = 'aFcyON5sqPuzNDWxuPojCZBg3krlg0A1lQ7N0HHI7DXPJYjZoU'

# Setup tweepy to authenticate with Twitter credentials:
auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_TOKEN, ACCESS_SECRET)

# Create the api to connect to twitter with your creadentials
api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True)

#exit if api failed
if (not api):
    print ("Can't Authenticate")
    sys.exit(-1)

#function to grab the first coordinate in a tweets bounding box
def grabFirstCoordinate(rawBoundingBox):
        firstCoordinateWithThreeBraces, otherThreeCoordinates = rawBoundingBox.split("]",1) #split at the end of the first coordinate
        firstBrace, secondBrace, thirdBrace, firstCoordinate = firstCoordinateWithThreeBraces.split("[")
        return firstCoordinate

# function to jitter a tweets coordinates within the passed in bounding box. the bounding box should be in the string 
# form of [[[-74.107995, 40.666879], [-74.0253309, 40.666879], [-74.0253309, 40.769124], [-74.107995, 40.769124]]].
# returns lat and log. 
def twitterJitter (dirtyBoundingBox):
        dirtyBottomLeft, dirtyBottomRight , dirtyTopRight, dirtyopLeft, excessFromBoundingBox = dirtyBoundingBox.split("]",4)
        excessFromBottomLeft, excessFromBottomLeft2, excessFromBottomLeft3, bottomLeft = dirtyBottomLeft.split("[")
        excessFromTopRight, topRight = dirtyTopRight.split("[")
        bottomLeftLog, bottomLeftLat = bottomLeft.split(",")
        topRightLog, topRightLat = topRight.split(",")
        jitteredLat = random.uniform(float(bottomLeftLat),float(topRightLat))
        jitteredLog = random.uniform(float(bottomLeftLog),float(topRightLog))
        return jitteredLog, jitteredLat     

# this is what we're searching for
searchQuery = ( '“green card” OR “permanent resident” OR “legal resident” OR “border security” OR “human smuggling” OR “detention centers” OR “border patrol” OR “illegal alien” OR “kids in cages” OR “build the wall” OR “anchor baby” OR immigrant OR migrant OR immigration OR migration OR #anchorbaby OR #buildthewall OR daca OR illegals OR undacamented OR naturalization OR undocumented OR asylum OR refugee')

maxTweets = 90000000 # Some arbitrary large number
tweetsPerQry = 100  # this is the max the API permits
fName = 'data/immigrationTopicsTweets.txt' # We'll store the tweets in a text file.
csvFile = open('data/immigrationTopicsTweets.csv', 'a') # Tweets to be stored in this csv file
csvWriter = csv.DictWriter(csvFile, fieldnames= ['tweetID','tweetText','tweetCity','tweetBoundingBox',
                                                'tweetLog','tweetLat','tweetCreated'])
#write header of csv file
csvWriter.writeheader()

# If results from a specific ID onwards are reqd, set since_id to that ID.
# else default to no lower limit, go as far back as API allows
sinceId = 1241967950715900000

# If results only below a specific ID are, set max_id to that ID.
# else default to no upper limit, start from the most recent tweet matching the search query.
max_id = -1
#used for debugging purposes
contar = 0
# seed random number generator
seed()


tweetCount = 0
print("Downloading max {0} tweets".format(maxTweets)) #print number of tweets that have processed
with open(fName, 'w') as f:
    while tweetCount < maxTweets:
        try:
            if (max_id <= 0):
                if (not sinceId):
                    new_tweets = api.search(q=searchQuery, count=tweetsPerQry, geocode ='39.828348,-98.579479,1400mi', lang = 'en', tweet_mode='extended')
                else:
                    new_tweets = api.search(q=searchQuery, geocode ='39.828348,-98.579479,1400mi', lang = 'en', count=tweetsPerQry, tweet_mode='extended',
                                            since_id=sinceId, )
            else:
                if (not sinceId):
                    new_tweets = api.search(q=searchQuery, geocode ='39.828348,-98.579479,1400mi', lang = 'en', count=tweetsPerQry, tweet_mode='extended',
                                            max_id=str(max_id - 1))
                else:
                    new_tweets = api.search(q=searchQuery, geocode ='39.828348,-98.579479,1400mi', lang = 'en', count=tweetsPerQry, tweet_mode='extended',
                                            max_id=str(max_id - 1),
                                            since_id=sinceId)
            if not new_tweets:
                print("No more tweets found")
                break
            #loop through the processed tweets
            for tweet in new_tweets:
                tweetJsonTest = tweet._json #variable of tweet saved in .json format

                #conditional to check if the tweet is a reweet to grab full text
                #of of the tweet. else, grab original tweets text
                if 'retweeted_status' in tweetJsonTest:
                    tweetFullText = tweetJsonTest['retweeted_status']['full_text']
                else:
                    tweetFullText = tweet.full_text

                tweetID = tweet.id_str #saves tweet id attribute into a string variable 
                fetchedPlace = str(tweet.place) #saves the geo-tagged attribute place of a tweet
                fetchedCoordiantes = str(tweet.coordinates) #saves the coordinate attribute of a tweet
                
                #conditional checking to see if the geo-tagged attribute "place" exists for a tweet and
                #checks to see if the "place_type" attribute is of city granularity
                if ((len(fetchedPlace) > 10) and (tweetJsonTest['place']['place_type'] == 'city')): 
                    log, lat = twitterJitter(str(tweetJsonTest['place']['bounding_box']['coordinates']))
                    csvWriter.writerow({
                        'tweetID':tweet.id_str,
                        'tweetText':tweetFullText,
                        'tweetCity':tweetJsonTest['place']['full_name'],
                        'tweetBoundingBox':tweetJsonTest['place']['bounding_box']['coordinates'],
                        'tweetLog':log,
                        'tweetLat':lat,
                        'tweetCreated':tweet.created_at,
                    })
                    f.write('Tweet ID: ' + tweetID  + '\n'+ 'Tweet Text: '+ tweetFullText + '\n'+
                    'These are the coordinantes: ' + fetchedCoordiantes + '\n' +
                    'This is the place: ' + fetchedPlace + '\n' 
                    + ' End of tweet %d' %(contar) + '\n\n')
                    contar = contar + 1
            tweetCount += len(new_tweets)
            print("Downloaded {0} tweets".format(tweetCount))
            max_id = new_tweets[-1].id
        except tweepy.TweepError as e:
            # Just exit if any error
            print("some error : " + str(e))
            break
csvFile.close()


