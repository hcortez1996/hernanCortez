import folium
import csv
from random import seed
from random import random
import pandas as pd

# function to parse the tweet cities bounding box and calculate the center of the city
# and using the first and third coordinate
def centerOfCity (dirtyBoundingBox):
        dirtyBottomLeft, dirtyBottomRight , dirtyTopRight, dirtyopLeft, excessFromBoundingBox = dirtyBoundingBox.split("]",4)
        excessFromBottomLeft, excessFromBottomLeft2, excessFromBottomLeft3, bottomLeft = dirtyBottomLeft.split("[")
        excessFromTopRight, topRight = dirtyTopRight.split("[")
        bottomLeftLog, bottomLeftLat = bottomLeft.split(",")
        topRightLog, topRightLat = topRight.split(",")
        midLat = ((float(bottomLeftLat) + float(topRightLat)) / 2.0)
        midLog = ((float(bottomLeftLog) + float(topRightLog)) / 2.0)
        return midLog, midLat  


#create map using folium import (zoomed in and centered on US)
m = folium.Map(location=[39.828348,-98.579479], zoom_start=5, ) 

#documents you wish to pass in
doc1 = 's1combined(processed).csv'
doc2 = 's2combined(processed).csv'
docSet = [doc1, doc2]

cities = dict()

# data structruce for all the tweet's cities
#_______________________________0__________1_______2________3___________4_________5_____
# cities["City, State"] = [boundingBox, midLog, midLat, numOfGreen, numOfGray, numOfRed]

# open docs in docset and print each unique city in a new row. also, keep track of how 
# many negaive, neutral, and positive tweets there are for each city. 
for doc in docSet:
    with open('data/processedData/{0}'.format(doc),'r',encoding='ISO-8859-1') as rf:
        csvReader = csv.DictReader(rf)  
        for row in csvReader: 
            if row['tweetCity'] not in cities:
                middleLog, middleLat = centerOfCity(row['tweetBoundingBox'])
                cities[row['tweetCity']] = [row['tweetBoundingBox'], middleLog, middleLat, 1, 1, 1]
                if row['tweetRawSentimentColor'] == 'green':
                   cities[row['tweetCity']][3] = cities[row['tweetCity']][3]+1
                elif row['tweetRawSentimentColor'] == 'gray':
                   cities[row['tweetCity']][4] = cities[row['tweetCity']][4]+1
                elif row['tweetRawSentimentColor'] == 'red':
                   cities[row['tweetCity']][5] = cities[row['tweetCity']][5]+1
            else:
                if row['tweetRawSentimentColor'] == 'green':
                   cities[row['tweetCity']][3] = cities[row['tweetCity']][3]+1
                elif row['tweetRawSentimentColor'] == 'gray':
                   cities[row['tweetCity']][4] = cities[row['tweetCity']][4]+1
                elif row['tweetRawSentimentColor'] == 'red':
                   cities[row['tweetCity']][5] = cities[row['tweetCity']][5]+1

#output all the cities with the greatest number of total tweets listed first
citiesWithMostTweets = sorted(cities.items(), key=lambda x: ( x[1][3]+x[1][4]+x[1][5] ), reverse=True)


#write a csv file containing stats, tweet counts, and tweet sentiment percentages per city
#for the top 1000 cities with the most tweets
with open('data/processedData/cityStats.csv','w',newline='',encoding='ISO-8859-1') as wf:
   csvWriter = csv.DictWriter(wf, fieldnames= ['city', 'numOfPosTweets', 'numOfNeuTweets', 
                                               'numOfNegTweets','totalNumOfTweets',
                                               'posTweetsPercentage', 'neuTweetsPercentage',
                                               'negTweetsPercentage'])
   csvWriter.writeheader()
   for i in citiesWithMostTweets[:1000]:
      nameOfCity = i[0]
      numOfPosTweets = i[1][3]
      numOfNeuTweets = i[1][4]
      numOfNegTweets = i[1][5]
      totalNumOfTweets = i[1][3]+i[1][4]+i[1][5]
      posTweetsPercentage = round(((i[1][3])/(i[1][3]+i[1][4]+i[1][5]))*100,2)
      neuTweetsPercentage = round(((i[1][4])/(i[1][3]+i[1][4]+i[1][5]))*100,2)
      negTweetsPercentage = round(((i[1][5])/(i[1][3]+i[1][4]+i[1][5]))*100,2)
      csvWriter.writerow({
         'city': nameOfCity,
         'numOfPosTweets': numOfPosTweets,
         'numOfNeuTweets': numOfNeuTweets,
         'numOfNegTweets': numOfNegTweets,
         'totalNumOfTweets': totalNumOfTweets,
         'posTweetsPercentage': posTweetsPercentage,
         'neuTweetsPercentage': neuTweetsPercentage,
         'negTweetsPercentage': negTweetsPercentage
      })
wf.close()

print('done')