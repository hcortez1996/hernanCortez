# -*- coding: utf-8 -*- 
import csv
import re
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer 
from random import seed
from random import random
import random


#fuction that uses vaderSentiment to determine sentiment scores on
#text that is passed in. also added color as an output for the map markers
def sentiment_scores(text): 
    # Create a SentimentIntensityAnalyzer object. 
    sid_obj = SentimentIntensityAnalyzer() 
  
    # polarity_scores method of SentimentIntensityAnalyzer 
    # oject gives a sentiment dictionary. 
    # which contains pos, neg, neu, and compound scores. 
    sentiment_dict = sid_obj.polarity_scores(text) 
      
    # decide sentiment as positive, negative and neutral 
    if sentiment_dict['compound'] >= 0.05 : 
        color = 'green'  
    elif sentiment_dict['compound'] <= - 0.05 : 
        color = 'red' 
    else : 
        color = 'gray'
    return sentiment_dict, color

#function that takes in text and cleans it of special characters and the links 
# at the end of tweets
def clean_tweet(tweet): 
		#Utility function to clean tweet text by removing links, special characters 
		#using simple regex statements. 
		return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", tweet).split())

# function to jitter a tweets coordinates within the passed in bounding box. the bounding box should be in the string 
# form of [[[-74.107995, 40.666879], [-74.0253309, 40.666879], [-74.0253309, 40.769124], [-74.107995, 40.769124]]].
# returns lat and log. 
def twitterJitter (dirtyBoundingBox):
        dirtyBottomLeft, dirtyBottomRight , dirtyTopRight, dirtyopLeft, excessFromBoundingBox = dirtyBoundingBox.split("]",4)
        excessFromBottomLeft, excessFromBottomLeft2, excessFromBottomLeft3, bottomLeft = dirtyBottomLeft.split("[")
        excessFromTopRight, topRight = dirtyTopRight.split("[")
        bottomLeftLog, bottomLeftLat = bottomLeft.split(",")
        topRightLog, topRightLat = topRight.split(",")
        jitteredLat = random.uniform(float(bottomLeftLat),float(topRightLat))
        jitteredLog = random.uniform(float(bottomLeftLog),float(topRightLog))
        return jitteredLog, jitteredLat   

# seed random number generator
seed()

#read in the tweets from csv file passed in and create new csv file with sentiment processing
with open('data/processedData/s2combined.csv','r',encoding='ISO-8859-1') as rf:
	#write new .csv file and populate it with transferring data from orginal csv file passed in with the 
	#addition of adding sentiment scores and colors. Writing new csv file headers
	with open('data/processedData/s2combined(processed).csv','w',newline='',encoding='ISO-8859-1') as wf:
		csvReader = csv.DictReader(rf)
		csvWriter = csv.DictWriter(wf, fieldnames= ['tweetID','tweetText','tweetCleanText','tweetCity','tweetBoundingBox',
													'tweetLog','tweetLat','tweetCreated','tweetRawSentimentDict',
													'tweetCleanSentimentDict','tweetRawSentimentColor','tweetCleanSentimentColor'])
		csvWriter.writeheader()
		#copying data from original csv file to new csv file, also use sentiment_scores function to process tweet texts
		#and to produce sentiment colors
		for row in csvReader:
			tID,tText,tCity,tBbox,tLog,tLat,tCreated=row['tweetID'],row['tweetText'],row['tweetCity'],row['tweetBoundingBox'],row['tweetLog'],row['tweetLat'],row['tweetCreated']
			tCleanText = clean_tweet(tText)
			tRawSentDict, tRawSentColor, = sentiment_scores(tText)
			tCleanSentDict, tCleanSentColor = sentiment_scores(tCleanText)
			csvWriter.writerow({
				'tweetID':tID,
				'tweetText':tText,
				'tweetCleanText':tCleanText,
				'tweetCity':tCity,
				'tweetBoundingBox':tBbox,
				'tweetLog':tLog,
				'tweetLat':tLat,
				'tweetCreated':tCreated,
				'tweetRawSentimentDict':tRawSentDict,
				'tweetCleanSentimentDict':tCleanSentDict,
				'tweetRawSentimentColor':tRawSentColor,
				'tweetCleanSentimentColor':tCleanSentColor
			})
	wf.close()
rf.close()
