import folium
import csv
from random import seed
from random import random
import pandas as pd

# function to parse the tweet cities bounding box and calculate the center of the city
# and using the first and third coordinate
def centerOfCity (dirtyBoundingBox):
        dirtyBottomLeft, dirtyBottomRight , dirtyTopRight, dirtyopLeft, excessFromBoundingBox = dirtyBoundingBox.split("]",4)
        excessFromBottomLeft, excessFromBottomLeft2, excessFromBottomLeft3, bottomLeft = dirtyBottomLeft.split("[")
        excessFromTopRight, topRight = dirtyTopRight.split("[")
        bottomLeftLog, bottomLeftLat = bottomLeft.split(",")
        topRightLog, topRightLat = topRight.split(",")
        midLat = ((float(bottomLeftLat) + float(topRightLat)) / 2.0)
        midLog = ((float(bottomLeftLog) + float(topRightLog)) / 2.0)
        return midLog, midLat  


#create map using folium import (zoomed in and centered on US)
m = folium.Map(location=[39.828348,-98.579479], zoom_start=5, ) 

#documents you wish to pass in
doc1 = 's1combined(processed).csv'
doc2 = 's2combined(processed).csv'
docSet = [doc1, doc2]

cities = dict()
#                                0         1       2         3           4         5
#cities["Chicago, IL"] = [boundingBox, midLog, midLat, numOfGreen, numOfGray, numOfRed]

# open docs in docset and to gather information needed to create map. I read every row and
# store all unique cities and keep track of all the positive, negative, and neutral tweets
# in each city
for doc in docSet:
    with open('data/processedData/{0}'.format(doc),'r',encoding='ISO-8859-1') as rf:
        csvReader = csv.DictReader(rf) 
        for row in csvReader: 
            if row['tweetCity'] not in cities:
                middleLog, middleLat = centerOfCity(row['tweetBoundingBox'])
                cities[row['tweetCity']] = [row['tweetBoundingBox'], middleLog, middleLat, 1, 1, 1]
                if row['tweetRawSentimentColor'] == 'green':
                   cities[row['tweetCity']][3] = cities[row['tweetCity']][3]+1
                elif row['tweetRawSentimentColor'] == 'gray':
                   cities[row['tweetCity']][4] = cities[row['tweetCity']][4]+1
                elif row['tweetRawSentimentColor'] == 'red':
                   cities[row['tweetCity']][5] = cities[row['tweetCity']][5]+1
            else:
                if row['tweetRawSentimentColor'] == 'green':
                   cities[row['tweetCity']][3] = cities[row['tweetCity']][3]+1
                elif row['tweetRawSentimentColor'] == 'gray':
                   cities[row['tweetCity']][4] = cities[row['tweetCity']][4]+1
                elif row['tweetRawSentimentColor'] == 'red':
                   cities[row['tweetCity']][5] = cities[row['tweetCity']][5]+1
            
#create new csvfile containing all the unique cities and tweets in them
csvfile = "cities.csv"
with open('data/processedData/{0}'.format(csvfile),'w',newline='',encoding='ISO-8859-1') as csvfile:
    writer = csv.writer(csvfile)
    for key, value in cities.items():
       writer.writerow([key, value])

# loop through all the cities and plot three circle markers for each city. The markers
# are as follows: red = negative tweets, gray = neutral tweets, green = positive tweets
# and the markers increase in size the more tweets there are. The map is output to an 
# html file
for city in cities:
    folium.CircleMarker(location=[cities[city][2],cities[city][1]], 
        radius= cities[city][3], popup=("{0}".format(city) + '\n' + 
        "Positive %: {0}".format( ((cities[city][3])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"+'\n'+ 
        "Neutral %: {0}".format( ((cities[city][4])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"+'\n'+
        "Negative %: {0}".format( ((cities[city][5])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"
        ), color='green' ).add_to(m) #add marker to map
    folium.CircleMarker(location=[cities[city][2],cities[city][1]], 
        radius= cities[city][5], popup=("{0}".format(city) + '\n' + 
        "Positive %: {0}".format( ((cities[city][3])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"+'\n'+ 
        "Neutral %: {0}".format( ((cities[city][4])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"+'\n'+
        "Negative %: {0}".format( ((cities[city][5])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"
        ), color='red' ).add_to(m) #add marker to map
    folium.CircleMarker(location=[cities[city][2],cities[city][1]], 
        radius= cities[city][4], popup=("{0}".format(city) + '\n' + 
        "Positive %: {0}".format( ((cities[city][3])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"+'\n'+ 
        "Neutral %: {0}".format( ((cities[city][4])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"+'\n'+
        "Negative %: {0}".format( ((cities[city][5])/(cities[city][3]+cities[city][4]+cities[city][5]))*100 ) +"%"
        ), color='gray' ).add_to(m) #add marker to map
m.save('plot2.html')
print(m)