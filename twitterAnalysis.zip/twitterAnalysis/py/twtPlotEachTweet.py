import folium
import csv
from random import seed
from random import random

#create map using folium import (zoomed in and centered on US)
m = folium.Map(location=[39.828348,-98.579479], zoom_start=5, ) 

#documents you wish to pass in
doc1 = 's1combined(processed).csv'
doc2 = 's2combined(processed).csv'
docSet = [doc1,doc2]

# open docs in docset, read each row in each csv file and output each individiual tweet
# as a small circle marker on the map. 
for doc in docSet:
    with open('data/processedData/{0}'.format(doc),'r',encoding='ISO-8859-1') as rf:
        csvReader = csv.DictReader(rf)  
        for row in csvReader: 
            folium.Circle(location=[row['tweetLat'],row['tweetLog']], radius= 1, 
            popup=("{0}, {1}".format(row['tweetCity'], row['tweetCreated']) +'\n'+ 
            "Tweet Text: {0}".format(row['tweetText'])), color=row['tweetRawSentimentColor'] 
            ).add_to(m) 

# save map visual as an html file named tweetsSmallMarkers.html. also, print map
# object to show the program is done running.
m.save('tweetsSmallMarkers.html') 
print(m) 

