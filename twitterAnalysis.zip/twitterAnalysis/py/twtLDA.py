import folium
from random import seed
from random import random
from collections import Counter
import random
import csv
import string
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import RegexpTokenizer
from stop_words import get_stop_words
from nltk.stem.porter import PorterStemmer
from gensim import corpora, models
import gensim
from gensim.utils import simple_preprocess
from gensim.parsing.preprocessing import STOPWORDS
from gensim.models import CoherenceModel
from nltk.stem import WordNetLemmatizer, SnowballStemmer
import pyLDAvis
import pyLDAvis.gensim 
import numpy as np
import warnings
import logging
import matplotlib.pyplot as plt
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt


# Enable logging for gensim - optional
# Set up log to external log file
logging.basicConfig(filename='lda_model.log', format='%(asctime)s : %(levelname)s : %(message)s', level=logging.DEBUG)

# Set up log to terminal
warnings.filterwarnings("ignore",category=DeprecationWarning)
np.random.seed(2018)

# tokenizer and lemmatizer
tokenizer = RegexpTokenizer(r'\w+')
lemmatizer = WordNetLemmatizer()

# create English stop words list
en_stop = get_stop_words('en')

#documents you wish to pass in
doc1 = 's1combined(processed).csv'
doc2 = 's2combined(processed).csv'
docSet = [doc1, doc2]

#function to remove punctuation from text passed in
def removePunctuation(text):
	noPunct = "".join([c for c in text if c not in string.punctuation])
	return noPunct

#function to remove stopwords from text passed in
def removeStopwords (text):
	words = [w for w in text if w not in stopwords.words('english')]
	return words

#function to lemmatize the text passed in
def wordLemmatizer (text):
	lemText = [lemmatizer.lemmatize(i) for i in text]
	return lemText

	
#function to clean tweet text by removing links, special characters using simple regex statements.
def clean_tweet(tweet):  
	return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)", " ", tweet).split())

#simple print statement to show program is still funning
print("gathering tweet tokens...")

#open and read all tweet data csv files and proccess all the tweet texts into acceptable input
#for LDA creation. All the tweet texts are stored in tweetTexts[].
tweetTexts = []
for doc in docSet:
        with open('data/processedData/{0}'.format(doc),'r',encoding='ISO-8859-1') as rf:
                csvReader = csv.DictReader(rf)
                for row in csvReader:
                        
                        # clean and tokenize documents string
                        tText = row['tweetText']                        
                        removeSmallWords = re.sub(r'\b\w{1,3}\b', '', tText)
                        rawLowerCase = removeSmallWords.lower()                    
                        cleanedRaw = clean_tweet(rawLowerCase)
                        punctRemoved = removePunctuation(cleanedRaw)
                        tokens = tokenizer.tokenize(punctRemoved)         
                        stopwordsRemoved = removeStopwords(tokens)
                        lemmatedWords = wordLemmatizer(stopwordsRemoved)

                        # add tokens to list
                        tweetTexts.append(lemmatedWords)                        
        rf.close()

#create one list of all tokens produced from the tweets
flatList = []
for sublist in tweetTexts:
    for item in sublist:
        flatList.append(item)

#create bigrams from all the tokens produced from the tweets
bigrams = zip(flatList, flatList[1:])
counts = Counter(bigrams)
print(counts.most_common(50))

#create trigrams from all the tokens produced from all the tweets
trigrams = zip(flatList, flatList[1:], flatList[2:])
counts = Counter(trigrams)
print(counts.most_common(50))

# turn our tokenized documents into a id <-> term dictionary
dictionary = corpora.Dictionary(tweetTexts)

# Filter out words that occur less than 20 documents, or more than 50% of the documents.
dictionary.filter_extremes(no_below=20, no_above=0.5)

# convert tokenized documents into a document-term matrix
corpus = [dictionary.doc2bow(text) for text in tweetTexts]

#simple print statement to show number of unique tokens and total documents used
print('Number of unique tokens: %d' % len(dictionary))
print('Number of documents: %d' % len(corpus))

# get user input for number of topics and words per topic
numberOfTopics = int(input("Enter the number of topics: "))
numberOfWordsPerTopic = int(input("Enter the number of words per topic: "))
numberOfPasses = int(input("Enter the number of passes for accuracy: "))

# generate LDA model by passing corpus and user input
ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics=numberOfTopics, 
                                            id2word = dictionary, passes=numberOfPasses, 
                                            eval_every = 1, iterations = 400, 
                                            chunksize=100)

# print LDA model
print(ldamodel.print_topics(num_topics=numberOfTopics, num_words=numberOfWordsPerTopic))

#wordcloud visualization
for t in range(ldamodel.num_topics):
    plt.figure()
    plt.imshow(WordCloud(background_color="black", colormap="gist_rainbow", prefer_horizontal=1).fit_words(dict(ldamodel.show_topic(t, 30))))
    plt.axis("off")
    plt.title("Topic #" + str(t+1))
    plt.show()


# Compute Coherence Score
coherence_model_lda = CoherenceModel(model=ldamodel, texts=tweetTexts, dictionary=dictionary, coherence='c_v')
coherence_lda = coherence_model_lda.get_coherence()
print('\nCoherence Score: ', coherence_lda)

#pyLDAvis visualization out put to html file
p = pyLDAvis.gensim.prepare(ldamodel, corpus, dictionary)
pyLDAvis.save_html(p, 'pyLDAvisFinal.html')
print("pyLDAvis is done.")
